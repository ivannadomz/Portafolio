let app = document.getElementById('typewriter');
 
let typewriter = new Typewriter(app, {
  loop: true,
  delay: 75,
});
 
typewriter
  .pauseFor(2500)
  .typeString('Soy estudiante de Ing en Software y desarrolladora de distintos programas')
  .pauseFor(200)
  .deleteChars(10)
  .start();
